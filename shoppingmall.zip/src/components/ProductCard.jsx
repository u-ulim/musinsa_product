import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const Img = styled.img`
  width: 300px;
  margin-bottom: 10px;
  border-radius: 10px;
`;

const ProductCard = ({ item }) => {
  console.log(item);
  return (
    <Wrapper>
      {/* <Img src=`{${item && item?.img}` /> */}
      <Img src={item && item.img} />
      <div>Conscious Choice</div>
      <div>{item && item?.title}</div>
      <div>{item && item?.price}</div>
      <div>{item && item?.new === true ? "신제품" : "이벤트상품"}</div>
    </Wrapper>
  );
};

export default ProductCard;
